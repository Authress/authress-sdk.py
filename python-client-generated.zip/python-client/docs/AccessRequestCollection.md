# AccessRequestCollection

A collection of access requests

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**records** | [**List[AccessRequest]**](AccessRequest.md) | A list of access requests | [optional] 
**pagination** | [**Pagination**](Pagination.md) |  | [optional] 
**links** | [**CollectionLinks**](CollectionLinks.md) |  | 

## Example

```python
from authress.models.access_request_collection import AccessRequestCollection

# TODO update the JSON string below
json = "{}"
# create an instance of AccessRequestCollection from a JSON string
access_request_collection_instance = AccessRequestCollection.from_json(json)
# print the JSON string representation of the object
print AccessRequestCollection.to_json()

# convert the object into a dict
access_request_collection_dict = access_request_collection_instance.to_dict()
# create an instance of AccessRequestCollection from a dict
access_request_collection_form_dict = access_request_collection.from_dict(access_request_collection_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


