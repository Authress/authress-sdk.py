# CollectionLinks


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**var_self** | [**Link**](Link.md) |  | 
**next** | [**Link**](Link.md) |  | [optional] 

## Example

```python
from authress.models.collection_links import CollectionLinks

# TODO update the JSON string below
json = "{}"
# create an instance of CollectionLinks from a JSON string
collection_links_instance = CollectionLinks.from_json(json)
# print the JSON string representation of the object
print CollectionLinks.to_json()

# convert the object into a dict
collection_links_dict = collection_links_instance.to_dict()
# create an instance of CollectionLinks from a dict
collection_links_form_dict = collection_links.from_dict(collection_links_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


