# ConnectionCollection

A collection of connections.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**connections** | [**List[Connection]**](Connection.md) |  | 
**pagination** | [**Pagination**](Pagination.md) |  | [optional] 

## Example

```python
from authress.models.connection_collection import ConnectionCollection

# TODO update the JSON string below
json = "{}"
# create an instance of ConnectionCollection from a JSON string
connection_collection_instance = ConnectionCollection.from_json(json)
# print the JSON string representation of the object
print ConnectionCollection.to_json()

# convert the object into a dict
connection_collection_dict = connection_collection_instance.to_dict()
# create an instance of ConnectionCollection from a dict
connection_collection_form_dict = connection_collection.from_dict(connection_collection_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


