# LinkedGroup

The referenced group

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**group_id** | [**GroupId**](GroupId.md) |  | 

## Example

```python
from authress.models.linked_group import LinkedGroup

# TODO update the JSON string below
json = "{}"
# create an instance of LinkedGroup from a JSON string
linked_group_instance = LinkedGroup.from_json(json)
# print the JSON string representation of the object
print LinkedGroup.to_json()

# convert the object into a dict
linked_group_dict = linked_group_instance.to_dict()
# create an instance of LinkedGroup from a dict
linked_group_form_dict = linked_group.from_dict(linked_group_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


