# PermissionCollection

A collect of permissions that the user has to a resource.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account** | [**PermissionCollectionAccount**](PermissionCollectionAccount.md) |  | [optional] 
**user_id** | [**UserId**](UserId.md) |  | 
**permissions** | [**List[PermissionObject]**](PermissionObject.md) | A list of the permissions | 

## Example

```python
from authress.models.permission_collection import PermissionCollection

# TODO update the JSON string below
json = "{}"
# create an instance of PermissionCollection from a JSON string
permission_collection_instance = PermissionCollection.from_json(json)
# print the JSON string representation of the object
print PermissionCollection.to_json()

# convert the object into a dict
permission_collection_dict = permission_collection_instance.to_dict()
# create an instance of PermissionCollection from a dict
permission_collection_form_dict = permission_collection.from_dict(permission_collection_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


